# USB-RS485 Sensor Tool v0.9.2

Standalone utility for USB-to-RS485 Modbus sensors and EPEVER Tracer-AN G3 configuration.

For the standalone build, run `USB_RS485_Sensor_Tool.exe` or
`START_USB_RS485_SENSOR_TOOL.bat`. To run from source, execute
`INSTALL_REQUIREMENTS.bat` once and then `START_USB_RS485_SENSOR_TOOL.bat`.

## TUF-2000M + TS-2

Select `TUF-2000M + TS-2 Ultrasonic Flow Meter`, use address 1 and profile
baud 9600, then click `Send read request`. One action reads flow/velocity,
M08 error bits, M90 signal diagnostics, M91 time ratio, net/positive/negative
accumulated volume, inner pipe diameter, and M46 device address. Every complete
TX/RX frame is shown.

REAL4 values use the hardware-confirmed `LOW_WORD_FIRST` layout. Raw
REG0221-REG0222 bytes `00 00 42 64` decode to the commissioned 57.0 mm inner
diameter only after swapping the two 16-bit words.

REG0113-REG0118 are decoded directly in cubic metres. The profile remains
read-only and does not attempt the interactive M37 totalizer reset.

## EPEVER Config

The EPEVER Config tab can read and write selected Tracer-AN G3 settings using Modbus FC10:

- battery type = User;
- battery capacity Ah;
- voltage block `0x9003..0x900E` as one group;
- rated voltage level `0x9067`;
- max charging current `0x90BF`;
- EPEVER ID/address change using the captured custom service command `0x45`.

## EPEVER address change

v0.8.0 adds EPEVER ID change using the proprietary/custom service command `0x45`. This is not normal Modbus FC06/FC10.

Commands:

```text
Find/read ID: F8 45 00 01 01 F8 + CRC
Set ID:       F8 45 00 01 01 NN + CRC
Example 0x60: F8 45 00 01 01 60 88 14
```

Use this only when exactly one EPEVER controller is connected to the USB-RS485 adapter. After writing, the app verifies the new and old addresses using a normal FC04 battery-voltage read.

Do not use `0x9020` as an address register. In the uploaded G3 protocol it is Turn-Off Voltage, not ID/address.


## v0.8.0 notes

The EPEVER tab is now split into settings on the left and a permanently visible TX/RX log on the right. False voltage-order blocking for config.h values has been fixed: 0x900A and 0x900B are treated as separate chains.
